
import React, { useRef, useEffect } from "react";
import { CheckCircle, Star, Clock, Ticket } from "lucide-react";

const services = [
  {
    title: "Priority Access",
    description: "Get tickets before they're available to the general public for high-demand events.",
    icon: <Clock className="h-10 w-10 text-secondary" />
  },
  {
    title: "VIP Experiences",
    description: "Exclusive access to premium seating, backstage passes, and meet-and-greet opportunities.",
    icon: <Star className="h-10 w-10 text-secondary" />
  },
  {
    title: "Global Coverage",
    description: "Access to tickets for events across the world, from concerts to sporting events.",
    icon: <Ticket className="h-10 w-10 text-secondary" />
  },
  {
    title: "Guaranteed Authenticity",
    description: "All tickets come with our authenticity guarantee for your peace of mind.",
    icon: <CheckCircle className="h-10 w-10 text-secondary" />
  }
];

const ServicesSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const serviceRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const options = {
      root: null,
      rootMargin: "0px",
      threshold: 0.1
    };

    const handleIntersect = (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate-fade-in");
          observer.unobserve(entry.target);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersect, options);
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    serviceRefs.current.forEach(ref => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      id="services" 
      className="py-20 bg-white"
      ref={sectionRef}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16 opacity-0" ref={el => serviceRefs.current[0] = el}>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Premium Services</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            We provide exceptional ticket reselling services with a focus on premium experiences and customer satisfaction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {services.map((service, index) => (
            <div 
              key={index}
              ref={el => serviceRefs.current[index + 1] = el}
              className="p-6 rounded-xl border border-border bg-card transition-all duration-300 hover:shadow-lg opacity-0"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex flex-col md:flex-row gap-4 items-start">
                <div className="p-3 rounded-lg bg-accent">
                  {service.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
