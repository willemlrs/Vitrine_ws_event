
import React, { useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

const ContactSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contactRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const options = {
      root: null,
      rootMargin: "0px",
      threshold: 0.1
    };

    const handleIntersect = (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate-fade-in");
          observer.unobserve(entry.target);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersect, options);
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    contactRefs.current.forEach(ref => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  // Replace with your actual contact information
  const email = "contact@eventhorizon.com";
  const phone = "+1 (555) 123-4567";
  const address = "123 Ticket Lane, Event City, EC 12345";
  const hours = "Monday-Friday: 9AM-6PM";
  const whatsappNumber = "+123456789";

  return (
    <section 
      id="contact" 
      className="py-20 bg-gradient-to-b from-white to-muted"
      ref={sectionRef}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16 opacity-0" ref={el => contactRefs.current[0] = el}>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Have questions or need to get in touch? We're here to help you find the perfect tickets.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <Card className="opacity-0" ref={el => contactRefs.current[1] = el}>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-6">Get in Touch</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <Mail className="h-5 w-5 text-primary mt-1 mr-3" />
                  <div>
                    <p className="font-medium">Email</p>
                    <a href={`mailto:${email}`} className="text-primary hover:underline">
                      {email}
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-primary mt-1 mr-3" />
                  <div>
                    <p className="font-medium">Phone</p>
                    <a href={`tel:${phone}`} className="text-primary hover:underline">
                      {phone}
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-primary mt-1 mr-3" />
                  <div>
                    <p className="font-medium">Address</p>
                    <p className="text-muted-foreground">{address}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clock className="h-5 w-5 text-primary mt-1 mr-3" />
                  <div>
                    <p className="font-medium">Business Hours</p>
                    <p className="text-muted-foreground">{hours}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-primary text-primary-foreground opacity-0" ref={el => contactRefs.current[2] = el}>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-6">Connect on WhatsApp</h3>
              <p className="mb-6">
                For quick responses and instant ticket availability checks, connect with us on WhatsApp.
              </p>
              <div className="bg-white/10 p-5 rounded-lg mb-6">
                <p className="font-medium text-white mb-2">Benefits of WhatsApp Contact:</p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <div className="h-1.5 w-1.5 rounded-full bg-secondary mr-2"></div>
                    <span>Instant responses during business hours</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-1.5 w-1.5 rounded-full bg-secondary mr-2"></div>
                    <span>Send photos of specific seating preferences</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-1.5 w-1.5 rounded-full bg-secondary mr-2"></div>
                    <span>Secure, end-to-end encrypted communication</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-1.5 w-1.5 rounded-full bg-secondary mr-2"></div>
                    <span>Real-time updates on ticket availability</span>
                  </li>
                </ul>
              </div>
              <Button asChild variant="secondary" className="w-full">
                <a 
                  href={`https://wa.me/${whatsappNumber}?text=Hello! I'm interested in event tickets.`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Chat with Us on WhatsApp
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
